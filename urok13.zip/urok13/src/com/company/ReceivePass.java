package com.company;

import java.text.ParseException;

public interface ReceivePass {
    void receive() throws ParseException;
    void pass();
}
